var input="C:/Users/User/AppData/Local/VEGAS Pro/18.0/-7E12BCA2.avi";
var output="C:/Users/User/Documents/Generated Clips/-AB266A7E.avi";
var size=3;
var repeat=10;
